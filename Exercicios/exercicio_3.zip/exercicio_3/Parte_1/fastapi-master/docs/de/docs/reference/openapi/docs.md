# OpenAPI `docs`

Werkzeuge zur Verwaltung der automatischen OpenAPI-UI-Dokumentation, einschließlich Swagger UI (standardmäßig unter `/docs`) und ReDoc (standardmäßig unter `/redoc`).

::: fastapi.openapi.docs.get_swagger_ui_html

::: fastapi.openapi.docs.get_redoc_html

::: fastapi.openapi.docs.get_swagger_ui_oauth2_redirect_html

::: fastapi.openapi.docs.swagger_ui_default_parameters

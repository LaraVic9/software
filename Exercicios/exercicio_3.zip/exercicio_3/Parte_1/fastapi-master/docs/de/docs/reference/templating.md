# Templating – `Jinja2Templates`

Sie können die `Jinja2Templates`-Klasse verwenden, um Jinja-Templates zu rendern.

Lesen Sie mehr darüber in der [FastAPI-Dokumentation zu Templates](../advanced/templates.md).

Sie können die Klasse direkt von `fastapi.templating` importieren:

```python
from fastapi.templating import Jinja2Templates
```

::: fastapi.templating.Jinja2Templates

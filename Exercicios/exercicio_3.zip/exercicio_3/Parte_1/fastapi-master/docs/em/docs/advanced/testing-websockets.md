# 🔬 *️⃣

👆 💪 ⚙️ 🎏 `TestClient` 💯*️⃣.

👉, 👆 ⚙️ `TestClient` `with` 📄, 🔗*️⃣:

```Python hl_lines="27-31"
{!../../../docs_src/app_testing/tutorial002.py!}
```

!!! note
    🌅 ℹ, ✅ 💃 🧾 <a href="https://www.starlette.io/testclient/#testing-websocket-sessions" class="external-link" target="_blank">🔬 *️⃣ </a>.

# OpenAPI-`models`

OpenAPI Pydantic-Modelle, werden zum Generieren und Validieren der generierten OpenAPI verwendet.

::: fastapi.openapi.models

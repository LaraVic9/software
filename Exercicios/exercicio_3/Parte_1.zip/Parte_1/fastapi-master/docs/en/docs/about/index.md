# About

About FastAPI, its design, inspiration and more. 🤓

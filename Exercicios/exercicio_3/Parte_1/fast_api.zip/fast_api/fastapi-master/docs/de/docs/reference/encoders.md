# Encoder – `jsonable_encoder`

::: fastapi.encoders.jsonable_encoder

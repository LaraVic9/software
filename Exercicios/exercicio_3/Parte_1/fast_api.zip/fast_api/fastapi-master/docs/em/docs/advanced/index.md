# 🏧 👩‍💻 🦮

## 🌖 ⚒

👑 [🔰 - 👩‍💻 🦮](../tutorial/index.md){.internal-link target=_blank} 🔜 🥃 🤝 👆 🎫 🔘 🌐 👑 ⚒ **FastAPI**.

⏭ 📄 👆 🔜 👀 🎏 🎛, 📳, &amp; 🌖 ⚒.

!!! tip
    ⏭ 📄 **🚫 🎯 "🏧"**.

     &amp; ⚫️ 💪 👈 👆 ⚙️ 💼, ⚗ 1️⃣ 👫.

## ✍ 🔰 🥇

👆 💪 ⚙️ 🏆 ⚒ **FastAPI** ⏮️ 💡 ⚪️➡️ 👑 [🔰 - 👩‍💻 🦮](../tutorial/index.md){.internal-link target=_blank}.

&amp; ⏭ 📄 🤔 👆 ⏪ ✍ ⚫️, &amp; 🤔 👈 👆 💭 👈 👑 💭.

## 🏎.🅾 ↗️

🚥 👆 🔜 💖 ✊ 🏧-🔰 ↗️ 🔗 👉 📄 🩺, 👆 💪 💚 ✅: <a href="https://testdriven.io/courses/tdd-fastapi/" class="external-link" target="_blank">💯-💾 🛠️ ⏮️ FastAPI &amp; ☁</a> **🏎.🅾**.

👫 ⏳ 🩸 1️⃣0️⃣ 💯 🌐 💰 🛠️ **FastAPI**. 👶 👶
